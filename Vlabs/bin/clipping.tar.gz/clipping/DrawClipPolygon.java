package clipping;
import java.applet.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.URL;


import library.DrawToolkit;
import library.Point;
import library.Polygon;

public class DrawClipPolygon extends Applet  implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static int ObjectLimit_x=500;
	private static int ObjectLimit_y=10;
	//private static int anSpeed=1;
	private static int pointRadii=4;
	private static int pointer=0;
	int RenderObject[][]=new int[ObjectLimit_x][ObjectLimit_y];
	//private static int counter=0;
	private static int state=0;
	private static int [][]curpoly=new int [ObjectLimit_x][2];
	private static int [][]newline=new int[ObjectLimit_x][2];
	private static int newlinecount=0;
	private static int polyvertices=0;
	private static int gotoNextStep=0;


	int width, height;
	private static DrawToolkit draw;
	private static int xmin,xmax,ymin,ymax;
	//Button information
	private static final String NextButtonName = "Next";
	private static final String PreviousButtonName = "Reset";
	private static final int nextButtonWidth = 20;
	private static final int previousButtonWidth = 20;
	private static final int nextButtonHeight = 10;
	private static final int previousButtonHeight = 10;
	private static final int fixedBottomGap = 20;
	
	public DrawClipPolygon(){
		for (int i=0;i<ObjectLimit_x;i++)
		{
			curpoly[i][0]=curpoly[i][1]=0;
			newline[i][0]=newline[i][1]=0;
		}
		
	}

	private int transx(int a)
	{
	return a;	
	}
	private int transy(int a)
	{
	return height-a;	
	}
	
	public void init()
	{
		String str="",temp="";
		Polygon P=new Polygon();
		Polygon Cp=new Polygon();
		String[] str1 = new String[15];
		BufferedReader br = null;
		Point[] PT=null;
		PT=new Point[10];
		Point[] PT1=new Point[60];
		for (int i=0;i<4;i++)
				PT[i]=new Point();
		for (int i=0;i<60;i++)
			PT1[i]=new Point();
	
		
		PolygonClipping PC = null;
		PC=new PolygonClipping();
	//	width = getSize().width;
      //  height = getSize().height;
        //System.out.println("Width"+width);
        //System.out.println("Height"+height);
		
		try
		{
			URL url = new URL(this.getCodeBase(), this.getParameter("file_name"));
			br = new BufferedReader(new InputStreamReader(url.openStream()));
			//Read data from the file
			
			/*
			FileInputStream fstream = new FileInputStream("/home/kaustav/Documents/CVIT/Vlabs/src/clipping/inputpoly");
			DataInputStream in = new DataInputStream(fstream);
	        br = new BufferedReader(new InputStreamReader(in));
	        */
	        
	        setSize(800, 600);
	        width = getSize().width;
	        height = getSize().height;
	        
	       while ( (temp = br.readLine() ) !=null)
	       {
	    	   str=str+" "+temp;
	       }
	        System.out.println(str);
	        str1=str.split(" ");
	        
	        int x,y;
	        
	        for(int i=0;i<8;i+=2)
	        {
	        	x=Integer.parseInt(str1[i+1]);
		        y=Integer.parseInt(str1[i+2]);
		       	PT[Math.round(i/2)].setPoint(x,y);
		        P.addVertex(PT[(i/2)]);
	        }
	        int numPoly=Integer.parseInt(str1[9]);
	        
	        for(int i=9;i<(2*numPoly)+9;i+=2)
	        {
	        	
	        	x=Integer.parseInt(str1[i+1]);
		        y=Integer.parseInt(str1[i+2]);
		        
	                (PT1[(i-9)/2]).setPoint(x,y);
	                Cp.addVertex(PT1[(i-9)/2]);
	        }
	        
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		RenderObject=PC.Clip(Cp, P);
		for (int i=0;RenderObject[i][0]!=-2;i++)
		{
			if(RenderObject[i][0]==0)
			{			
				RenderObject[i][2]=transy(RenderObject[i][2]);
			}
			else
			{			
				RenderObject[i][3]=transy(RenderObject[i][3]);
				RenderObject[i][5]=transy(RenderObject[i][5]);
			}
				//System.out.println(i+" "+RenderObject[i][0]+" "+RenderObject[i][1]+" "+RenderObject[i][2]+" "+RenderObject[i][3]+" "+RenderObject[i][4]+" "+RenderObject[i][5]+" "+RenderObject[i][6]);
		}
		draw = new DrawToolkit();
        //resize(width);
        
        // Make the default background color black.
        setBackground( Color.black );
        
        int boundary[];
        boundary=new int[4];
        //Get end points of the Polygon
        P.getRectangleBoundary(boundary);
        xmin=transx(boundary[0]);
        xmax=transx(boundary[1]);
        ymin=transy(boundary[2]);
        ymax=transy(boundary[3]);
        
        //Make next button and previous button
        Button next = new Button(NextButtonName);
		Button previous = new Button(PreviousButtonName);
		next.setBounds((getWidth() - nextButtonWidth)/2, getHeight() - nextButtonHeight - fixedBottomGap,
				nextButtonWidth, nextButtonHeight);
		previous.setBounds((getWidth() - previousButtonWidth)/2, getHeight() - previousButtonHeight - fixedBottomGap,
				previousButtonWidth, previousButtonHeight);
		add(next);
		add(previous);
		next.setBackground(Color.WHITE);
		previous.setBackground(Color.WHITE);
		next.addActionListener(this);
		previous.addActionListener(this);
        
		pointer=0;
		state=0;
	
	}
	private void RenderClipLine(Graphics g,int choice)
	{
	        if (1==choice )
	        {
	        	draw.makeLine(g,xmin, ymin, xmin, ymax,Color.yellow, false);
                draw.writeCoordinates(g,xmin, ymin,xmin, transy(ymin),Color.yellow);
                draw.writeCoordinates(g,xmax, ymax,xmax, transy(ymax),Color.yellow);
	        }
	        if (2==choice )
	        {
	        	draw.makeLine(g,xmax, ymin, xmax, ymax,Color.yellow, false);
                draw.writeCoordinates(g,xmax, ymin,xmax, transy(ymin),Color.yellow);
                draw.writeCoordinates(g,xmax, ymax,xmax, transy(ymax),Color.yellow);
	        }
	        if (3==choice )
	        {
	        	draw.makeLine(g,xmin, ymin, xmax, ymin,Color.yellow, false);
                draw.writeCoordinates(g,xmin, ymin,xmin, transy(ymin),Color.yellow);
                draw.writeCoordinates(g,xmax, ymin,xmax, transy(ymin),Color.yellow);
	                
	        }
	        if (4==choice )
	        {
	        	draw.makeLine(g,xmax, ymax, xmin, ymax,Color.yellow, false);
                draw.writeCoordinates(g,xmax, ymax,xmin, transy(ymax),Color.yellow);
                draw.writeCoordinates(g,xmax, ymax,xmin, transy(ymax),Color.yellow);
            
	        }
	}
	private void makenewLines(Color c1,Graphics g)
	{
	        int i;
	        for(i=0;i<newlinecount;i++)
	        {
	                draw.makeFilledRoundPoint(g,newline[i][0],newline[i][1],pointRadii,c1);
	                draw.makeFilledRoundPoint(g,newline[i+1][0],newline[i+1][1],pointRadii,c1);
	                draw.makeLine(g,newline[i][0],newline[i][1],newline[i+1][0],newline[i+1][1],c1,false);
	                draw.writeCoordinates(g,newline[i][0],newline[i][1],newline[i][0],transy(newline[i][1]),c1);
			         draw.writeCoordinates(g,newline[i+1][0],newline[i+1][1],newline[i+1][0],transy(newline[i+1][1]), c1);
	                
	                i++;
	        }

	}

	
	void polyanimate(Graphics g)
	{
		 if(state==0)
	        {
	                int i=0;
	          
	                if(RenderObject[pointer][0]==0)
	                {
	                        polyvertices=0;
	                        newlinecount=0;
	                        
	                        for(i=pointer;RenderObject[i][0]==0;i++)
	                        {
	                                polyvertices++;
	                                curpoly[i-pointer][0]=RenderObject[i][1];
	                                curpoly[i-pointer][1]=RenderObject[i][2];
	                        }
	                        
	                        
	                        System.out.println("Pointer value 1 " + pointer);
	                        draw.makeCPolygon(g,curpoly,height,polyvertices,pointRadii,Color.white);
	                        
	                        pointer=i;
	                        
	                }
	                else if((RenderObject[pointer][1]==2) || (RenderObject[pointer][1]==1))
	                {
	                        draw.makeCPolygon(g,curpoly,height,polyvertices,pointRadii,Color.white);
	                        RenderClipLine(g,RenderObject[pointer][0]); //Selects the clipping line of the window
	                        makenewLines(Color.red,g); //Draws the new clipped polygon
	                        draw.makeLine(g,RenderObject[pointer][2], RenderObject[pointer][3],RenderObject[pointer][4],RenderObject[pointer][5],Color.yellow,false); //Selects the clip line of the polygon
	                        draw.writeCoordinates(g,RenderObject[pointer][2],RenderObject[pointer][3],RenderObject[pointer][2],transy(RenderObject[pointer][3]), Color.yellow);
		 			        draw.writeCoordinates(g,RenderObject[pointer][4],RenderObject[pointer][5],RenderObject[pointer][4],transy(RenderObject[pointer][5]), Color.yellow);
		 	                
	                        if(RenderObject[pointer][1]==2)
	                        {
	                                draw.makeLine(g,RenderObject[pointer][2], RenderObject[pointer][3],RenderObject[pointer][4],RenderObject[pointer][5],Color.red,false); //Selects the clip line of the window
	                                draw.writeCoordinates(g,RenderObject[pointer][2],RenderObject[pointer][3],RenderObject[pointer][2],transy(RenderObject[pointer][3]), Color.red);
	    		 			        draw.writeCoordinates(g,RenderObject[pointer][4],RenderObject[pointer][5],RenderObject[pointer][4],transy(RenderObject[pointer][5]), Color.red);
	    		 	                
	                                newline[newlinecount][0]=RenderObject[pointer][2];newline[newlinecount][1]=RenderObject[pointer][3];
	                                newline[newlinecount+1][0]=RenderObject[pointer][4];newline[newlinecount+1][1]=RenderObject[pointer][5];
	                                //cout<< "newline"<<newlinecount<<endl;
	                        }
	                }
	               
	                if((gotoNextStep==1 ))
	                {
	                        pointer++;
	                        if(RenderObject[pointer-1][1]==2)
	                                newlinecount+=2;
	                        if(RenderObject[pointer-1][0]==-2)
	                        {
	                        	draw.makeCPolygon(g,curpoly,height,polyvertices,pointRadii,Color.green);
		                        pointer=0;
		                        newlinecount=0;
		                        state=1;
   
	                        	
	                        }
	                        gotoNextStep=0;
	                }
	        }
	        else
	        {
	                draw.makeCPolygon(g,curpoly,height,polyvertices,pointRadii,Color.green);

	        }

	}
	
	
	public void paint (Graphics g)
	{

		 draw.drawCoordinate(g,width,height,Color.white);
	     draw.makeNRectangle(g,xmin,xmax,ymin,ymax,Color.white,false,false);
	     draw.writeCoordinates(g, xmin, ymin, xmin,transy(ymin) ,Color.white);
	     draw.writeCoordinates(g, xmin, ymax, xmin,transy(ymax) ,Color.white);
	     draw.writeCoordinates(g, xmax, ymax, xmax,transy(ymax) ,Color.white);
	     draw.writeCoordinates(g, xmax, ymin, xmax,transy(ymin) ,Color.white);
			
	     polyanimate(g);

	}
		
	
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getActionCommand() == NextButtonName)
        {
                gotoNextStep=1;
        }
        if(e.getActionCommand() == PreviousButtonName)
        {
                pointer=0;
                state=0;
        }
        repaint();
		
	}
	
}