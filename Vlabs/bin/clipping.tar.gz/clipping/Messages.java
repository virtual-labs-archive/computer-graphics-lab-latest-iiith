package clipping;

public class Messages {


	// String Display Position
	public static final int stringxDisplay = 800;
	public static final int stringyDisplay = 150;
	
	public static final String topSide = "Clipping against Top Side"; 
	public static final String leftSide = "Clipping against Left Side";
	public static final String rightSide = "Clipping against Right Side";
	public static final String bottomSide = "Clipping against Bottom Side";
}
