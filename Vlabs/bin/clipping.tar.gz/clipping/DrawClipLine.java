package clipping;
import java.applet.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.URL;


import library.DrawToolkit;
import library.Line;
import library.Point;
import library.Polygon;

public class DrawClipLine extends Applet  implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static ReturnObject RO;
	int width, height;
	private static DrawToolkit draw;
	private static int xmin,xmax,ymin,ymax;
	private float pointRadii=(float) 4.0;
	private int pointer=0;
	
	// Button information
	private static final String NextButtonName = "Next";
	private static final String PreviousButtonName = "Previous";
	
	//Window size
	private static final int horizontalWindowSize = 600;
	private static final int verticalWindowSize = 600;
	private static final int horizontalCoordinateSize = 600;
	private static final int verticalCoordinateSize = 600;
	
	//String display information
	private static final int shiftXcoordinate = 2;
	private static final int shiftYcoordinate = 4;
	
	private static final int nextButtonWidth = 20;
	private static final int previousButtonWidth = 20;
	private static final int nextButtonHeight = 10;
	private static final int previousButtonHeight = 10;
	private static final int fixedBottomGap = 20;
	
	// Colour information
	private static final Color coordinateColor = Color.white;
	private static final Color clippingWindowColor = Color.white;
	private static final Color gridColor = Color.orange;
	private static final Color clippedLineColor = Color.gray;
	private static final Color clippingLineColor = Color.magenta.brighter();
	private static final Color highlightColor = Color.blue;
	private static final Color highlightPointColor = Color.yellow;
	private static final Color acceptColor = Color.green;
	private static final Color binaryColor = Color.white;
	
	// It controls when should we move to next step
	private int gotoNextStep=1;
	
	private int transx(int a)
	{
	return a;	
	}
	private int transy(int a)
	{
	return height-a;	
	}
	
	
	public void init()
	{
		String str="",temp="";
		Polygon P=new Polygon();
		Line L;
		LineClipping LC =new LineClipping();
		String[] str1 = new String[15];
		BufferedReader br = null;
		        
        setSize(horizontalWindowSize, verticalWindowSize);

		width = getSize().width;
        height = getSize().height;
        System.out.println("Width"+width);
        System.out.println("Height"+height);
        
		try
		{
			URL url = new URL(this.getCodeBase(), this.getParameter("file_name"));
			br = new BufferedReader(new InputStreamReader(url.openStream()));
			
			//Read data from the file
			/*
			FileInputStream fstream = new FileInputStream("/home/kaustav/Documents/CVIT/Vlabs/src/clipping/inputline");
			DataInputStream in = new DataInputStream(fstream);
	        br = new BufferedReader(new InputStreamReader(in));
	        */
	       while ( (temp = br.readLine() ) !=null)
	       {
	    	   str=str+" "+temp;
	       }
	        System.out.println(str);
	        str1=str.split(" ");
	        
	        int x,y;
	        x=Integer.parseInt(str1[1]);
	        y=Integer.parseInt(str1[2]);
	        Point rect1 = new Point(x,y);
	        x=Integer.parseInt(str1[3]);
	        y=Integer.parseInt(str1[4]);
	        Point rect2 = new Point(x,y);
	        x=Integer.parseInt(str1[5]);
	        y=Integer.parseInt(str1[6]);
	        Point rect3 = new Point(x,y);
	        x=Integer.parseInt(str1[7]);
	        y=Integer.parseInt(str1[8]);
	        Point rect4 = new Point(x,y);
	        x=Integer.parseInt(str1[9]);
	        y=Integer.parseInt(str1[10]);
	        Point p1 = new Point(x,y);
	        x=Integer.parseInt(str1[11]);
	        y=Integer.parseInt(str1[12]);
	        Point p2 = new Point(x,y);
	        P.addVertex(rect1);P.addVertex(rect2);P.addVertex(rect3);P.addVertex(rect4);
	        
	        //Clip the line
	        L=new Line(p1,p2);
	        RO=LC.Clip(L, P);
	        
	        int boundary[];
	        boundary=new int[4];
	        //Get end points of the Polygon
	        P.getRectangleBoundary(boundary);
	        xmin=transx(boundary[0]);
	        xmax=transx(boundary[1]);
	        ymin=transy(boundary[2]);
	        ymax=transy(boundary[3]);
	        
	        //Display the object got after clipping the line
	        for(int i=0;i<RO.count;i++)
			{
	        	
	        	RO.RenderObject[i][1]=RO.RenderObject[i][1];
	        	RO.RenderObject[i][2]=transy(RO.RenderObject[i][2]);
	        	RO.RenderObject[i][3]=transx(RO.RenderObject[i][3]);
	        	RO.RenderObject[i][4]=transy(RO.RenderObject[i][4]);
	        	for(int j=0;j<7;j++)
					System.out.print(RO.RenderObject[i][j]+ " ");
				
			System.out.println("");	
			}
	        System.out.println(RO.count);
	        
	        //Make a object for Drawing Shapes
	        draw = new DrawToolkit();
	        //resize(width);
	        
	        // Make the default background color black.
	        setBackground( Color.black );
	        
	        
	        
	        //Make next button and previous button
	        Button next = new Button(NextButtonName);
			Button previous = new Button(PreviousButtonName);
			next.setBounds((getWidth() - nextButtonWidth)/3, getHeight() - nextButtonHeight - fixedBottomGap,
					nextButtonWidth, nextButtonHeight);
			previous.setBounds((getWidth() - previousButtonWidth)/3, getHeight() - previousButtonHeight - fixedBottomGap,
					previousButtonWidth, previousButtonHeight);
			add(next);
			add(previous);
			next.setBackground(Color.WHITE);
			previous.setBackground(Color.WHITE);
			next.addActionListener(this);
			previous.addActionListener(this);
	        
	        
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	
	}
	void renderclipLine(int side, Graphics g)
	{
		            //Draw Line from the current points in given color and highlight the current point
	
			        draw.makeLine(g,RO.RenderObject[pointer][1],RO.RenderObject[pointer][2],RO.RenderObject[pointer][3],RO.RenderObject[pointer][4],highlightColor, false);
			        draw.writeCoordinates(g,RO.RenderObject[pointer][1]+ shiftXcoordinate,RO.RenderObject[pointer][2]- shiftYcoordinate,RO.RenderObject[pointer][1],transy(RO.RenderObject[pointer][2])  , highlightColor);
			        draw.writeCoordinates(g,RO.RenderObject[pointer][3] + shiftXcoordinate,RO.RenderObject[pointer][4]- shiftYcoordinate,RO.RenderObject[pointer][3],transy(RO.RenderObject[pointer][4])  , highlightColor);
	                draw.makeFilledRoundPoint(g,RO.RenderObject[pointer][1],RO.RenderObject[pointer][2],pointRadii,highlightPointColor);
	                draw.writeString(g,RO.RenderObject[pointer][1]-1,RO.RenderObject[pointer][2]+10,RO.RenderObject[pointer][5],binaryColor);//This writes the code of the point
			        draw.writeString(g,RO.RenderObject[pointer][3]-1,RO.RenderObject[pointer][4]+10,RO.RenderObject[pointer][6],binaryColor);//This writes the code of the point
		        
			        //Make the sides of the clip window
	                if(side==1)
	                {
	                g.drawString(Messages.leftSide, Messages.stringxDisplay, Messages.stringyDisplay);
	                draw.makeLine(g,xmin, ymin, xmin, ymax,clippingLineColor, false);
	                draw.writeCoordinates(g,xmin+ shiftXcoordinate, ymin- shiftYcoordinate,xmin, transy(ymin),clippingLineColor);
	                draw.writeCoordinates(g,xmin+ shiftXcoordinate, ymax- shiftYcoordinate,xmin, transy(ymax),clippingLineColor);
	                }
	                else if(side ==2)
	                {
	                	g.drawString(Messages.rightSide, Messages.stringxDisplay, Messages.stringyDisplay);
	                    draw.makeLine(g,xmax, ymin, xmax, ymax,clippingLineColor, false);
	                    draw.writeCoordinates(g,xmax+ shiftXcoordinate, ymin- shiftYcoordinate,xmax, transy(ymin),clippingLineColor);
		                draw.writeCoordinates(g,xmax+ shiftXcoordinate, ymax- shiftYcoordinate,xmax, transy(ymax),clippingLineColor);
	                }
	                else if(side ==3)
	                {
	                	g.drawString(Messages.bottomSide, Messages.stringxDisplay, Messages.stringyDisplay);
	                    draw.makeLine(g,xmin, ymin, xmax, ymin,clippingLineColor, false);
	                    draw.writeCoordinates(g,xmin+ shiftXcoordinate, ymin- shiftYcoordinate,xmin, transy(ymin),clippingLineColor);
		                draw.writeCoordinates(g,xmax+ shiftXcoordinate, ymin- shiftYcoordinate,xmax, transy(ymin),clippingLineColor);
	                }
	                else if(side ==4)
	                {
	                	g.drawString(Messages.topSide, Messages.stringxDisplay, Messages.stringyDisplay);
	                    draw.makeLine(g,xmax, ymax, xmin, ymax,clippingLineColor, false);
	                    draw.writeCoordinates(g,xmax+ shiftXcoordinate, ymax- shiftYcoordinate,xmax, transy(ymax),clippingLineColor);
		                draw.writeCoordinates(g,xmin+ shiftXcoordinate, ymax- shiftYcoordinate,xmin, transy(ymax),clippingLineColor);
	                
	                }
	                //sleep(anSpeed);
	}

	private void animate(Graphics g)
	{
		
		        if(RO.RenderObject[pointer][0]==-2)
		        {
		                //This is executed when the line is completely clipped
		                if(RO.accept==true)
		                {
		                	 draw.makeLine(g,RO.RenderObject[pointer][1],RO.RenderObject[pointer][2],RO.RenderObject[pointer][3],RO.RenderObject[pointer][4],acceptColor,false);
		                	 draw.writeCoordinates(g,RO.RenderObject[pointer][1]+ shiftXcoordinate,RO.RenderObject[pointer][2]- shiftYcoordinate,RO.RenderObject[pointer][1],transy(RO.RenderObject[pointer][2])  ,acceptColor);
		 			         draw.writeCoordinates(g,RO.RenderObject[pointer][3]+ shiftXcoordinate,RO.RenderObject[pointer][4]- shiftYcoordinate,RO.RenderObject[pointer][3],transy(RO.RenderObject[pointer][4])  , acceptColor);
		 	                
		                }    
		                g.drawString("Clipped Line", Messages.stringxDisplay, Messages.stringyDisplay);
	                	draw.makeNRectangle(g,xmin,xmax,ymin,ymax,acceptColor,false,false);
	                	 draw.writeCoordinates(g, xmin + shiftXcoordinate, ymin - shiftYcoordinate, xmin,transy(ymin) ,acceptColor);
	        		     draw.writeCoordinates(g, xmin + shiftXcoordinate, ymax - shiftYcoordinate, xmin,transy(ymax) ,acceptColor);
	        		     draw.writeCoordinates(g, xmax + shiftXcoordinate, ymax - shiftYcoordinate, xmax,transy(ymax) ,acceptColor);
	        		     draw.writeCoordinates(g, xmax + shiftXcoordinate, ymin - shiftYcoordinate, xmax,transy(ymin) ,acceptColor);
	        			
		                //sleep(anSpeed);
		        }
		        else if(RO.RenderObject[pointer][0]==0)
		        {
		                //There will be always be two coordinates succeeding zero in the data given by algorithm.  We draw a line from one point to another.
		                draw.makeLine(g,RO.RenderObject[pointer][1],RO.RenderObject[pointer][2],RO.RenderObject[pointer][3],RO.RenderObject[pointer][4],highlightColor,false); 
		                draw.writeCoordinates(g,RO.RenderObject[pointer][1]  + shiftXcoordinate,RO.RenderObject[pointer][2] - shiftYcoordinate,RO.RenderObject[pointer][1],transy(RO.RenderObject[pointer][2])  , highlightColor);
				        draw.writeCoordinates(g,RO.RenderObject[pointer][3] + shiftXcoordinate,RO.RenderObject[pointer][4] - shiftYcoordinate,RO.RenderObject[pointer][3],transy(RO.RenderObject[pointer][4])  , highlightColor);
		                draw.writeString(g,RO.RenderObject[pointer][1]-1,RO.RenderObject[pointer][2]+10,RO.RenderObject[pointer][5],binaryColor);//This writes the code of the point
				        draw.writeString(g,RO.RenderObject[pointer][3]-1,RO.RenderObject[pointer][4]+10,RO.RenderObject[pointer][6],binaryColor);//This writes the code of the point

		        }
		        else if(RO.RenderObject[pointer][0]==1)
		        {
		        //Highlight current point and the clip boundary it is being checked against in this case which is the left one.
		        renderclipLine(1,g);
		        }else if(RO.RenderObject[pointer][0]==2)
		        {
		        renderclipLine(2,g);
		        }
		        else if(RO.RenderObject[pointer][0]==3)
		        {
		        renderclipLine(3,g);
		        }
		        else if(RO.RenderObject[pointer][0]==4)
		        {
		        renderclipLine(4,g);
		        }
		        if(gotoNextStep==1)
		        {
		                pointer+=1;
//		              speedCounter=Speed;
		                gotoNextStep=0;
		        }
		        if(pointer==RO.count)
		                pointer=0;
		
	}
	
	public void paint (Graphics g)
		{
			 g.translate(20, 20);
			 draw.drawCoordinate(g,horizontalCoordinateSize,verticalCoordinateSize,coordinateColor);
		     draw.makeNRectangle(g,xmin,xmax,ymin,ymax,clippingWindowColor,false,false);
		     draw.writeCoordinates(g, xmin + shiftXcoordinate, ymin - shiftYcoordinate, xmin,transy(ymin) ,coordinateColor);
		     draw.writeCoordinates(g, xmin + shiftXcoordinate, ymax - shiftYcoordinate, xmin,transy(ymax) ,coordinateColor);
		     draw.writeCoordinates(g, xmax + shiftXcoordinate, ymax - shiftYcoordinate, xmax,transy(ymax) ,coordinateColor);
		     draw.writeCoordinates(g, xmax + shiftXcoordinate, ymin - shiftYcoordinate, xmax,transy(ymin) ,coordinateColor);
					  
		     draw.drawGrid(g,xmin,xmax,ymin,ymax,verticalCoordinateSize,horizontalCoordinateSize,gridColor);
		       // Draw Original line helps in seeing what portion has been clipped
		        //glLineWidth(1);
		        draw.makeLine(g,RO.RenderObject[0][1],RO.RenderObject[0][2],RO.RenderObject[0][3],RO.RenderObject[0][4],clippedLineColor,false);
		        draw.writeCoordinates(g,RO.RenderObject[0][1] + shiftXcoordinate, RO.RenderObject[0][2] - shiftYcoordinate,
		        	RO.RenderObject[0][1],transy(RO.RenderObject[0][2])  , clippedLineColor);
		        draw.writeCoordinates(g,RO.RenderObject[0][3] + shiftXcoordinate, RO.RenderObject[0][4] - shiftYcoordinate,
		            RO.RenderObject[0][3],transy(RO.RenderObject[0][4])  , clippedLineColor);
                
		        draw.writeString(g,RO.RenderObject[0][1] -1,RO.RenderObject[0][2] + 10,RO.RenderObject[0][5],clippedLineColor);//This writes the code of the point
		        draw.writeString(g,RO.RenderObject[0][3] -1,RO.RenderObject[0][4] + 10,RO.RenderObject[0][6],clippedLineColor);//This writes the code of the point

		        //glLineWidth(3);
		        animate(g);
			
		}
	
	public void actionPerformed(ActionEvent e) {
		if(pointer>=0)
		{
			if(e.getActionCommand() == NextButtonName)
			{
				gotoNextStep=1;
			}
			else if(e.getActionCommand() == PreviousButtonName)
			{
				
			    if((pointer-2)>=0)
	                    pointer-=2;
	            gotoNextStep=1;
			}
			System.out.println(pointer);
		repaint();
		}
	}
	
	
}
